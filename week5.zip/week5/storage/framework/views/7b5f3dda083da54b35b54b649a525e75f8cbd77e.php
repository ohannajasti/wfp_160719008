<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <style>

    </style>
</head>

<body>

    <div class="container">
        <h2>Products dengan kategori: <?php echo e($category_name); ?></h2>
        <p>Data ditemukan berjumlah <?php echo e(count($result)); ?> dari <?php echo e($getTotalData); ?></p>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Produk</th>
                    <th>Harga Produk</th>
                    <th>Harga Jual</th>
                    <th>Stok</th>
                    <th>Created at</th>
                    <th>Updated at</th>
                    <th>Category ID</th>
                    <th>Supplier ID</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    <tr>
                        <td><?php echo e($d->id); ?></td>
                        <td><?php echo e($d->nama_produk); ?></td>
                        <td><?php echo e($d->harga_produk); ?></td>
                        <td><?php echo e($d->harga_jual); ?></td>
                        <td><?php echo e($d->stok); ?></td>
                        <td><?php echo e($d->created_at); ?></td>
                        <td><?php echo e($d->updated_at); ?></td>
                        <td><?php echo e($d->category_id); ?></td>
                        <td><?php echo e($d->category->nama_kategori); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </div>
   
    </div>

    </div>
    </div>

</body>

</html>
<?php /**PATH C:\xampp7\htdocs\wfp\week4 - Copy\resources\views/report/showcake.blade.php ENDPATH**/ ?>